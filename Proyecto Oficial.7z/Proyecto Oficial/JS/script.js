console.log("Hello World!")
/*var num1= 5;
var num2=3;
var sum=num1+num2;
console.log(sum);*/

/*var num1= 5;
var num2=3;
var multi=num1*num2;
console.log(multi);*/

/*Math. sqrt(1244);
console.log("Raiz cuadrada con decimal");
console.log(Math.sqrt(1244));
parseInt(Math.sqrt(1244));
console.log("Raiz cuadrada entera")
console.log(parseInt(Math.sqrt(1244)));*/

/*console.log("Números primos del 1 al 500.000")
function esPrimo(numero) {
    
    for(let i = 2,raiz=Math.sqrt(numero); i <= raiz; i++)
        if(numero % i === 0) return false;
    return numero > 1;
}  
for (let x=0;x<=5000000;x++) {
    if (esPrimo(x))
        console.log("El número " + x + " es primo")
}*/

var c = 11;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
    if (j/j==c & j/1==j) {

        console.log(2,3,5,7,9)
    
    } 
  }
  
}



   
console.log(numerosPrimos);
function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}
